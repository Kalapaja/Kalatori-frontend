<?php
// Text
$_['text_title'] = 'Polkadot payment';